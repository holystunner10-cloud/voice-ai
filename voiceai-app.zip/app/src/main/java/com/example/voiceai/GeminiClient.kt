package com.example.voiceai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Sends a real request to the Gemini API and returns the real model response.
     * [history] is a list of (role, text) pairs — role is "user" or "model".
     */
    fun ask(prompt: String, history: List<Pair<String, String>>): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank()) {
            return "No Gemini API key was found in this build. Ask whoever built the app to set the GEMINI_API_KEY secret."
        }

        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(
                JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                }
            )
        }
        contents.put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }
        )

        val bodyJson = JSONObject().apply {
            put("contents", contents)
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        val body = bodyJson.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url(url).post(body).build()

        return try {
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: return "Empty response from Gemini."
                if (!response.isSuccessful) {
                    return "Gemini API error ${response.code}: $responseBody"
                }
                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) return "No response from Gemini."
                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts == null || parts.length() == 0) return "No response from Gemini."
                parts.getJSONObject(0).optString("text", "No response from Gemini.")
            }
        } catch (e: Exception) {
            "Network error talking to Gemini: ${e.message}"
        }
    }
}
